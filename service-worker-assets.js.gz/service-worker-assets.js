self.assetsManifest = {
  "version": "Fxd3I08I",
  "assets": [
    {
      "hash": "sha256-DubzVRAcefVzrUkPmvmpRqrTxVqS6U7EDctJJVvGgVM=",
      "url": "404.html"
    },
    {
      "hash": "sha256-9suC9LCVB+Qavj4prBgl/ufjjFZIUypz8Imx/0r5LsI=",
      "url": "SpawnDev.BlazorJS.lib.module.js"
    },
    {
      "hash": "sha256-EqXDxiXiUT45Tjsy0ZRAEE48nP4GKfu+wns7Xx34X28=",
      "url": "VVG.Web.styles.css"
    },
    {
      "hash": "sha256-YKVDuPPHaB1MmrEmJ2jX+5YKNk1lhwM87g93oW097XQ=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-qlACtw54l5jaJj9fmcYr0+j80MEZJYpJPEDBgGSDZfo=",
      "url": "_content/SpawnDev.BlazorJS.TransformersJS/transformers-3.8.1.js"
    },
    {
      "hash": "sha256-jJeL4ir0qfzqqYK6nw0VPVsZio8L0fZmh0oTTS8Q66A=",
      "url": "_framework/AngleSharp.Css.0t6wmu3plx.wasm"
    },
    {
      "hash": "sha256-QaFFsgfXwBbDi7+iM1r20lJ1SkEyr/+t6XV7nZFnzXk=",
      "url": "_framework/AngleSharp.Diffing.7u0ejwzz3c.wasm"
    },
    {
      "hash": "sha256-Y4sEENvtK/83f8mNpWJK5bO08oFlVvOWzaQV82kDcb4=",
      "url": "_framework/AngleSharp.bix3b1fduh.wasm"
    },
    {
      "hash": "sha256-BHekS+czPkgVWI+RR+8670vyrMkfy6M5NzXhcBZuszk=",
      "url": "_framework/Bunit.Core.gd63ciqekz.wasm"
    },
    {
      "hash": "sha256-XPBWHcP4fYVXCrdPuuLwWBLJ1QXM3co0zm8w5mTXrHU=",
      "url": "_framework/Bunit.Web.kamifsx96u.wasm"
    },
    {
      "hash": "sha256-t3lFppQa0mtcJhnAgH0CjaUgx5yVh9lHRfx3jZagZmQ=",
      "url": "_framework/Castle.Core.fqg0tyy8au.wasm"
    },
    {
      "hash": "sha256-Jv9S5coLP28fMUd+sd72uOfd5e3pWx+IFMRNtR/lykc=",
      "url": "_framework/Markdig.earcieyyzk.wasm"
    },
    {
      "hash": "sha256-neAgArvhZZ83bAvXp4Ty7+U1tXsW2FWJqsW649UrVCM=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.h7xioon6px.wasm"
    },
    {
      "hash": "sha256-yTTpGp8y/Fr71slNsRQeSKHJQFMT4VYzha9j9Juot0M=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.703kf01kgr.wasm"
    },
    {
      "hash": "sha256-jT8HTBtX7ODPhIWO7zmiMeKDJMcmYXh1JvKeR5+4aEo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.jsbj2brsl6.wasm"
    },
    {
      "hash": "sha256-tW7WP8TmfjBu9wdLVTOeSnruMwk9s9hd2mPgAnQ9fdo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.l45vnbsg8n.wasm"
    },
    {
      "hash": "sha256-lFFD0CddCqBY9HMpn266zilMGfyptpY4SmXvAakE4+A=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.09ti9pcaig.wasm"
    },
    {
      "hash": "sha256-s2ozGPBm/DN0zRbZTcuVEjwVKRbLPHp5BqjiUD/A9Rk=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.b2abras9rr.wasm"
    },
    {
      "hash": "sha256-rrqCSQt3DKNzdZxjHF5GaE8pXWFGmHO6JnVdgATDJJI=",
      "url": "_framework/Microsoft.AspNetCore.Components.qphg5mskm9.wasm"
    },
    {
      "hash": "sha256-EBu0K8SFe/KbDl6H4PhdQZcfOWBAQS9MiNm+0jjq0xo=",
      "url": "_framework/Microsoft.AspNetCore.Hosting.Abstractions.kb9z3q8jmd.wasm"
    },
    {
      "hash": "sha256-KOdV8nnepJvdzz9YZQF2IiESUrXNx6nNMN2Uvhssmi4=",
      "url": "_framework/Microsoft.AspNetCore.Hosting.Server.Abstractions.wyr9zkt2c4.wasm"
    },
    {
      "hash": "sha256-7wgz1ZHwXmXV8y00xn+jT4BGeuCQQbVYGQl+PNvBfnQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Abstractions.5jy9omvvsv.wasm"
    },
    {
      "hash": "sha256-sbIJEHnGL6std1HkIJ83mfNTk5yznrGRZbaacPDI5w4=",
      "url": "_framework/Microsoft.AspNetCore.Http.Extensions.57zig84vjd.wasm"
    },
    {
      "hash": "sha256-bzIPAVp+XhD63CRn9cVTB4tJRU+oDEAuwFYoHytMhUk=",
      "url": "_framework/Microsoft.AspNetCore.Http.Features.pqxjsc5k5q.wasm"
    },
    {
      "hash": "sha256-VLx+YinQktx45UmtVwPyFgIvwYk5/FCDiKfrMe2E/GQ=",
      "url": "_framework/Microsoft.AspNetCore.StaticFiles.sq1atuai2y.wasm"
    },
    {
      "hash": "sha256-D8oEWEHjIHgqnC972iD0zP5GFfXxilTh5Hc++6jf8O8=",
      "url": "_framework/Microsoft.CSharp.3fnyvcrtax.wasm"
    },
    {
      "hash": "sha256-II2IMFFwMrZ8T7O1jcKjyTGYt1jy8oh5T4fzISc4Fso=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.cxnwkyn2s5.wasm"
    },
    {
      "hash": "sha256-1CSpSnELBdonla8tfwlZdccFPghsyODoJdQPOKxBNOY=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.gdrljl4ot1.wasm"
    },
    {
      "hash": "sha256-rflmTVQUMHhg3Mj/C/wJrCeZUHp3Ehc8l2NnzEHUQTQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.95nmrkt5y4.wasm"
    },
    {
      "hash": "sha256-1y+HiAKbF6OQQk1mMwcqiDmk9C6LrRUGiP4uFK0Kwk8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.pc68mejkzb.wasm"
    },
    {
      "hash": "sha256-UfQcnVfpf3PrW1QUrKZvQL4DyaHP7DFcaGzWTOr3lcA=",
      "url": "_framework/Microsoft.Extensions.Configuration.nms7ni0iou.wasm"
    },
    {
      "hash": "sha256-YeIghji7kqAeNQmoLXaiSQHE3Sulq4Cgb3V3/gP4nnk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.9qjyyevksc.wasm"
    },
    {
      "hash": "sha256-SGLUcytQ+KWf193EvGpKAHD3ed5iRysCKKM8oSdXL50=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.06yzuiagrr.wasm"
    },
    {
      "hash": "sha256-aF6pE9ykFIEExjYpINTFJ5ofHIbkY2ReBBs5UeGLgO8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.8oc5vwtnuj.wasm"
    },
    {
      "hash": "sha256-/iDsfZxoLNisttYRq6DPEdWoemZXHSYCOEmyXC7s7yE=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.u5zojh40m9.wasm"
    },
    {
      "hash": "sha256-Hk8pW55zfveNvvjOKB1Fh6+mUh8dWFicnMlaPiBgw/A=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.epl4unp9d2.wasm"
    },
    {
      "hash": "sha256-8XH/JwBoO1Fp8XnlCJoeXR4PeGTZbQcgI6DUb1UhGkw=",
      "url": "_framework/Microsoft.Extensions.Logging.pmotwgjfsv.wasm"
    },
    {
      "hash": "sha256-AmK5n6+U3/TZLOrVpiIo8BOymvR7teo9Z2xKXf82gDI=",
      "url": "_framework/Microsoft.Extensions.Options.q5fxbq8vi3.wasm"
    },
    {
      "hash": "sha256-TJi5aZ26hPZdnkhQ6AI1A8J2eE0NiTLCiq457BHD/V4=",
      "url": "_framework/Microsoft.Extensions.Primitives.coqpxtzvgr.wasm"
    },
    {
      "hash": "sha256-2GXd0dzJSw1MZdFrFpqhpJxxHJajMOb3DRqEPvvAQyY=",
      "url": "_framework/Microsoft.Extensions.Validation.cjmva6optn.wasm"
    },
    {
      "hash": "sha256-Bdf9d9pn2Uq2eIqSFAduDgy/genNDe0U87Tc6tyw3fY=",
      "url": "_framework/Microsoft.Extensions.WebEncoders.vzzjoxjizn.wasm"
    },
    {
      "hash": "sha256-868Hu4wRAcobcZ73HckJ+beSdIK++ANKH0KFDDW+nqs=",
      "url": "_framework/Microsoft.JSInterop.3op4lo81cq.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-jfXK+cfJd/PteHB+5Bay/NDY9b9VLvVw6G/Bm262Lpo=",
      "url": "_framework/Microsoft.Net.Http.Headers.vhfw8f9f40.wasm"
    },
    {
      "hash": "sha256-pcZwouWq2s6ALLDR4aVKGKAHB8K8AHF19b/iiY8Lkiw=",
      "url": "_framework/Moq.32p2m2njz2.wasm"
    },
    {
      "hash": "sha256-JIo07sg6BjmGo8tGfICUCjqpfyRiEA+YYo91XWcnEGY=",
      "url": "_framework/SpawnDev.BackgroundServices.o55nwjvr9o.wasm"
    },
    {
      "hash": "sha256-qOJLY8Ylxhmh/a66FiTAaO9fPKiZgZ8kfuTw69itKxU=",
      "url": "_framework/SpawnDev.BlazorJS.TransformersJS.wyjhmqyku1.wasm"
    },
    {
      "hash": "sha256-93DIJxseA9V/kqOVH8fuUiAUH4I/jIKCp/HEQn9e3S4=",
      "url": "_framework/SpawnDev.BlazorJS.brig6i6kgn.wasm"
    },
    {
      "hash": "sha256-Txh+XJAQztWpShnI84UIZpRNhz7Qkw08H0YoXrYjvHo=",
      "url": "_framework/System.Buffers.92qr7xas64.wasm"
    },
    {
      "hash": "sha256-t+kMahFlB1WJWET3KCqdwcTKZScf3MQl1QVKaV1K2lQ=",
      "url": "_framework/System.Collections.Concurrent.hijqtpzfqk.wasm"
    },
    {
      "hash": "sha256-l9GCQbi/UrijQ7LCf7F6cLnVRc+npnOxE9yj31H0cls=",
      "url": "_framework/System.Collections.Immutable.1uzsefi0vh.wasm"
    },
    {
      "hash": "sha256-zfxkIPnCbgX7WjA8G2ZmDhk66n/nncf1N4Z7JXwUvbU=",
      "url": "_framework/System.Collections.NonGeneric.7nn2zj3jmv.wasm"
    },
    {
      "hash": "sha256-ewWBGXOqLXo7rhI5bVMkykHgH1EVx+8lKftccuDF1sE=",
      "url": "_framework/System.Collections.Specialized.v725zast7y.wasm"
    },
    {
      "hash": "sha256-4gt9J7uJAZJTiIIJENR58gWwOqKsVu8GXMYJnw8phj8=",
      "url": "_framework/System.Collections.y08te0rjsw.wasm"
    },
    {
      "hash": "sha256-Ov5oYowCsfo2rM0K6VqFaBK5ILvXlUbvMqVkulj8M9I=",
      "url": "_framework/System.ComponentModel.6157xawz3t.wasm"
    },
    {
      "hash": "sha256-usYacppa6UniWOOpkVMsnDLDUxwZm4xw0NmaqiVxKOo=",
      "url": "_framework/System.ComponentModel.Annotations.i1182sx910.wasm"
    },
    {
      "hash": "sha256-5oggE9xD8T3GDIqvtfieOrkBtePlBHTpyZlJwEamqAU=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.uzxckjw60t.wasm"
    },
    {
      "hash": "sha256-es3XK/CA4U26ofuA71tBXJJesOoqQ+R5jxpPp5CMr7w=",
      "url": "_framework/System.ComponentModel.Primitives.u26n01hkwc.wasm"
    },
    {
      "hash": "sha256-b4s4qNwLaRYYVy3hK70qcDRufbIHcakyRVKtCmQuM/A=",
      "url": "_framework/System.ComponentModel.TypeConverter.72qatbmxz0.wasm"
    },
    {
      "hash": "sha256-FQw8WS0T+P1Mt5l9Yi64uSvwt4sF3dOWkEbCztCcMMY=",
      "url": "_framework/System.Console.11vcko3z7z.wasm"
    },
    {
      "hash": "sha256-WZrbz8SyrVi+3PSpannQEahBl50RG/WGnv/vC8CcAL0=",
      "url": "_framework/System.Diagnostics.Debug.7ogdg826sz.wasm"
    },
    {
      "hash": "sha256-RAncengqAJBB+iN2bT/H0XpnKAsFwSOVjH8WMsiswZQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.gtedptnjgd.wasm"
    },
    {
      "hash": "sha256-IfNFv7mQDEwmxByqar8XV6/jKJJsbmFuaskJSZZEpmU=",
      "url": "_framework/System.Diagnostics.EventLog.dp9o0j0iim.wasm"
    },
    {
      "hash": "sha256-i2hFTF75Zw02NzEYBxCsOsJXWleKISzmMEcafmev4DA=",
      "url": "_framework/System.Diagnostics.StackTrace.vbijxxm9b9.wasm"
    },
    {
      "hash": "sha256-hMJTSmkDre0KQhCfbZvzKLgoY7LwBAmMeIH2VGuuFNk=",
      "url": "_framework/System.Diagnostics.Tools.0trz75b865.wasm"
    },
    {
      "hash": "sha256-TpmVvRDxyPxrO9v9HS7rzRiXoXXQ7jrEUrMWnKyYjjQ=",
      "url": "_framework/System.Diagnostics.TraceSource.e8m3yljwyp.wasm"
    },
    {
      "hash": "sha256-hvMWb18QQiTg+haq2LFXivORxD1BTg5jU7FwhULGGoY=",
      "url": "_framework/System.Diagnostics.Tracing.ez06aq56jv.wasm"
    },
    {
      "hash": "sha256-747heClgqy1bKhaBcwmHJDQBAYifbI5/09eGDqJbT4U=",
      "url": "_framework/System.Globalization.fcnj6vzffj.wasm"
    },
    {
      "hash": "sha256-SDrXZLyyqngegcR4It7FdCphhbVZPZLFGiXqEfC6s3s=",
      "url": "_framework/System.IO.Pipelines.osw9ot8gwu.wasm"
    },
    {
      "hash": "sha256-6qP2KaqRSKtySvh0zi45A9z6m25E3fs9EGOCtHSn5Nw=",
      "url": "_framework/System.IO.ufjy9lfo86.wasm"
    },
    {
      "hash": "sha256-bfJFjvOG3HU70LZrFWy0xak3lTE/TGtzneahBLGMioI=",
      "url": "_framework/System.Linq.Expressions.x3m2an14bv.wasm"
    },
    {
      "hash": "sha256-4RJVmhehwNFTQJ0MyPQKMmof5D/fM750DGJj8wtTmnU=",
      "url": "_framework/System.Linq.Queryable.dhjhq7cke9.wasm"
    },
    {
      "hash": "sha256-2JfF0CAQmfhZAKQxwavBXokq0htMgL0C/h+tkCSoQfc=",
      "url": "_framework/System.Linq.w6ybmgs5q6.wasm"
    },
    {
      "hash": "sha256-5Vg5OHvCBGCuqslscfXJlVPaGn4dhcHCFKDYSMPx5E8=",
      "url": "_framework/System.Memory.r470b6s4ek.wasm"
    },
    {
      "hash": "sha256-oTTkZ6sNT+M4GFmFNcLUVnnIfHqXicHTciKMjRnd+ew=",
      "url": "_framework/System.Net.Http.1gmkee8xzq.wasm"
    },
    {
      "hash": "sha256-digjQQJ7oHBhn/hcFvo/LGJeDFeVALmctQeEf6jVoJQ=",
      "url": "_framework/System.Net.Http.Json.qjv7x3eofi.wasm"
    },
    {
      "hash": "sha256-AItOuKp588DLmpPON6GiKxI5op/o8jelMEsmpq6iX/k=",
      "url": "_framework/System.Net.Mail.c5glgcj57v.wasm"
    },
    {
      "hash": "sha256-l3QVYywqccW6SuXKH1AruslNr3XpBzqnmtcv0EKxqBI=",
      "url": "_framework/System.Net.Primitives.d72p01hwaz.wasm"
    },
    {
      "hash": "sha256-Ei50ZEJ0v2A9NV+8iuk1gocBwW6KLEf8IwsF6Py6rBk=",
      "url": "_framework/System.Net.Requests.6v7purlf4j.wasm"
    },
    {
      "hash": "sha256-hVO6r+/zvuA58c9CI7BT92bw3wV8SiPHsRCtgn5gK8Y=",
      "url": "_framework/System.Net.ServicePoint.935ny2ftmm.wasm"
    },
    {
      "hash": "sha256-YyZyIquUwn8ZKli/Fms3533JUJHS7afuS5M58dFcYMo=",
      "url": "_framework/System.Net.WebHeaderCollection.zggssa66ip.wasm"
    },
    {
      "hash": "sha256-FAM0nVVYY+laKLhLGeWX6oiUld4Y3jUU1mqds9QLtA8=",
      "url": "_framework/System.Net.WebSockets.kcxlzp689t.wasm"
    },
    {
      "hash": "sha256-4zW/OsfLyHys6OBJtJ09sBLj1C/XcK63lZg0AEAz2cs=",
      "url": "_framework/System.ObjectModel.hbsbu2orwe.wasm"
    },
    {
      "hash": "sha256-NUk4djUgM0IxTXGnbCiuisv+f11OJguzDZrJ/U4o+6Y=",
      "url": "_framework/System.Private.CoreLib.5gjvx1rbms.wasm"
    },
    {
      "hash": "sha256-gGpwqRMWYfoY7NaAzahXYP1GPNTZUebnC148ZHnVhco=",
      "url": "_framework/System.Private.Uri.c9vtvmdrqy.wasm"
    },
    {
      "hash": "sha256-te7HKRCtE1OSV0ucdCvGmmnD6929o0kwsAojZaagUPc=",
      "url": "_framework/System.Private.Xml.frr36f8egj.wasm"
    },
    {
      "hash": "sha256-OKV2tlCchimmsmnvDIqQ6J2jx7tzzl9669feV6F3y5o=",
      "url": "_framework/System.Reflection.DispatchProxy.455ji6p8on.wasm"
    },
    {
      "hash": "sha256-wJipZBpcdKJM0QGBhehSixGvz4N0A3ynorujSE2dxuw=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.w8owqb37yc.wasm"
    },
    {
      "hash": "sha256-N3230WTP0KSa1wxLcob6tzKtyoXY7ycLSchQ3JZ1034=",
      "url": "_framework/System.Reflection.Emit.Lightweight.xa4k4v5awg.wasm"
    },
    {
      "hash": "sha256-8uoWsyOamm/vPzhUHrU6vTFuR5XhU2hXaAKZvHzVa/M=",
      "url": "_framework/System.Reflection.Emit.ecpbwk9hm2.wasm"
    },
    {
      "hash": "sha256-ix3xo01yXRfHH9PP2LRG9Cd/dVapm7RP5heIAxb9iMY=",
      "url": "_framework/System.Reflection.Extensions.97jdwk9jyp.wasm"
    },
    {
      "hash": "sha256-fgCUndxusEKURbq+tOGcYCrfHZliEwJYifI+LgbJQOU=",
      "url": "_framework/System.Reflection.Primitives.2kf3e0otkq.wasm"
    },
    {
      "hash": "sha256-Ua1jTGHTgr4u/dt9Cg/XFy/9+Su/MPYiK/FRgTyucis=",
      "url": "_framework/System.Reflection.td60xfrmem.wasm"
    },
    {
      "hash": "sha256-qTe99P+5u0uLGCUsQWV7xmeIHtZlxCBg508fllXYMck=",
      "url": "_framework/System.Runtime.39dly8tpyz.wasm"
    },
    {
      "hash": "sha256-1lepJCJsOGH09jhG5VXo6i5hripUz+3i+YbVT4oZaF4=",
      "url": "_framework/System.Runtime.Extensions.iil1h1v5pl.wasm"
    },
    {
      "hash": "sha256-orXDJ+k47PinKZ2FtzefqtlGM6rB3uolse7A5ghR1QI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2j7dj8dwvr.wasm"
    },
    {
      "hash": "sha256-uUK/Cmt4T7Mq78Aoew53kNJwUlvdPA7bp3XCCJdW3bs=",
      "url": "_framework/System.Runtime.InteropServices.dn3tnh7fdb.wasm"
    },
    {
      "hash": "sha256-6IdeD8lwwcHDWOexVbk0KRFTDMSJC3u4c1N7T1XM93g=",
      "url": "_framework/System.Runtime.Numerics.k59fk2kal4.wasm"
    },
    {
      "hash": "sha256-e5XNn/xY+Z3jNysy7JsVZmIOvWO6xZCZ2jr34Vlmtrw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.xd90b8ri0v.wasm"
    },
    {
      "hash": "sha256-e49h3Y8FwxHfUVO3HcygKdYCllJDZPLBaa3HM7lq/pE=",
      "url": "_framework/System.Security.Claims.p3gssd0xss.wasm"
    },
    {
      "hash": "sha256-eRoVusdhNar9QWGuT6chMAxAx2WgvmIdcOYnrdY6dEk=",
      "url": "_framework/System.Security.Cryptography.r7rn4ijfsl.wasm"
    },
    {
      "hash": "sha256-+LCExmCq9qrN5b7k8Brp657NzUIlPlGhYsL6tzHp6jo=",
      "url": "_framework/System.Text.Encoding.CodePages.416qyr82hf.wasm"
    },
    {
      "hash": "sha256-fQ8obTMWjSGFjfcCRghC6SqT43PRhrw++9xYGIANBwk=",
      "url": "_framework/System.Text.Encoding.Extensions.7jx7v3ecqo.wasm"
    },
    {
      "hash": "sha256-UmZNCPorVSgVe/21ae3m+unxP72FaZb1dXUYZT9TBDA=",
      "url": "_framework/System.Text.Encoding.u1tlgo70z2.wasm"
    },
    {
      "hash": "sha256-7kBYIFRtnEDjRCWqjT/yNuinstKEsMpuOAUX9s3tmmw=",
      "url": "_framework/System.Text.Encodings.Web.yo5hsrm5sw.wasm"
    },
    {
      "hash": "sha256-q/NVtafNdEya4v62pe55c3GnqWv6npyjkVPNHT/PjMw=",
      "url": "_framework/System.Text.Json.pnw893mblw.wasm"
    },
    {
      "hash": "sha256-hQ5anyOiWFdcFl6M9b/Oe5es9L8FK5kCUGoecYuvoa0=",
      "url": "_framework/System.Text.RegularExpressions.tyqs7kqvgb.wasm"
    },
    {
      "hash": "sha256-lreFWgIIm1bKEGJhBRrhkIyI+FOxgrBd1Q96ceLg7Ag=",
      "url": "_framework/System.Threading.Tasks.i2l3jiov66.wasm"
    },
    {
      "hash": "sha256-sS8mguFwc7Pq/oqzCDrzIzkxrucRMHur6cO+kaIwT2E=",
      "url": "_framework/System.Threading.j7kkp1liru.wasm"
    },
    {
      "hash": "sha256-bkkZRQZcsP1UpThGuGhH/Btr7NyKYjveE7aMn1giEvU=",
      "url": "_framework/System.Xml.ReaderWriter.uwh73w1uok.wasm"
    },
    {
      "hash": "sha256-o7em91RhiZoNr54kBhFjp3JOI+12tMHv7hDiGx9/UTo=",
      "url": "_framework/System.Xml.XPath.nfb3v72dcr.wasm"
    },
    {
      "hash": "sha256-bub0pEq4uXcOOFYyEUpbXITo0XxXqqfYsdiQMCTj77k=",
      "url": "_framework/System.Xml.XmlSerializer.ynpy0w7hk2.wasm"
    },
    {
      "hash": "sha256-QZM96Sbw2BYre4bcT9tJXUPU/9h0LdgAPwGMigVXC8g=",
      "url": "_framework/System.x4983syfn1.wasm"
    },
    {
      "hash": "sha256-ZKUwPOtCvuormreSCc1xyWMM3cD2S3jRZub8UpbqDsY=",
      "url": "_framework/VVG.Web.g9xonsk9e7.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-i4MH1ttKidpkFY/9i4kRe+7ux5JQMZds+qXuSkJqeog=",
      "url": "_framework/dotnet.native.f749u69f30.wasm"
    },
    {
      "hash": "sha256-95bE510j3EADMNW2OKa/DMBhu8N632dl5HGeBfXNEf4=",
      "url": "_framework/dotnet.native.rjbmzc4jpg.js"
    },
    {
      "hash": "sha256-e9ulUr/42Ux6TTy7IyGdxqM/uXisbYlzIr9Vfo8dUEg=",
      "url": "_framework/dotnet.r88vo2sa76.js"
    },
    {
      "hash": "sha256-YyudibIWETMKrLb+nAZdJ+xDY7HY6BWf6s32UAdcvCU=",
      "url": "_framework/dotnet.runtime.r2kbxkuujc.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VlD9BzqDScS5QpD+s7G5Jriz+BugZebDRMu3XJO1x6I=",
      "url": "_framework/netstandard.6dpd23ohq4.wasm"
    },
    {
      "hash": "sha256-FMbuMTkxDbIP6RfJCxjGvjndsldPgOAoaTQzqmvU+C0=",
      "url": "_framework/xunit.abstractions.4ksum12hez.wasm"
    },
    {
      "hash": "sha256-n7nICg3U9NxWD9/4GIqVCoc1iVPUFv8bxnBFu0xYqfk=",
      "url": "_framework/xunit.assert.r5lmtufxq8.wasm"
    },
    {
      "hash": "sha256-dO64otwr2k1vrtikDpYSDICUwTlSN+BS2e9flwaxgOA=",
      "url": "_framework/xunit.core.gdx2hak6yl.wasm"
    },
    {
      "hash": "sha256-lrSRy0/PouNa7Ehyd7R3fYByUU/rWWTDoZ4buOu38Xo=",
      "url": "_framework/xunit.execution.dotnet.idzueilo3g.wasm"
    },
    {
      "hash": "sha256-neInIS3fGPfnHE5U0yeWFHmCd2yASY5EucYwVoRJ/tA=",
      "url": "assets/css/_animations.scss"
    },
    {
      "hash": "sha256-CQ8zGmoEt5GPfcA5GfOFtGyn1P0uUSLb5tMbsniR62I=",
      "url": "assets/css/_blog.scss"
    },
    {
      "hash": "sha256-6ZPZv8wVSvvxRNvjxeP+oVzjlaLPARvfZSgiXQeBshc=",
      "url": "assets/css/_canvas.scss"
    },
    {
      "hash": "sha256-x5KWTfb+8LjabWdSA3tU9VnIULe/ZbOoKpRoH3j9jsw=",
      "url": "assets/css/_components.scss"
    },
    {
      "hash": "sha256-vgjHcawqSol1i3zef1m4EMP63d3rBRlZm6Y5EPeizaU=",
      "url": "assets/css/_layout.scss"
    },
    {
      "hash": "sha256-JNSvk5En0av1McbTOZ2orHa5j8lybQRSYsV31QmjwBM=",
      "url": "assets/css/_preloader.scss"
    },
    {
      "hash": "sha256-j34J2H0N8Zhqvq6qfBU0dAgRzDfZqhJ4+RgjPCbsTcQ=",
      "url": "assets/css/_terminal-like-services-page.scss"
    },
    {
      "hash": "sha256-FCCKzjK9jBjV2CE0VP8w6QwVKzx51ucFBiz1JvHc/OQ=",
      "url": "assets/css/_theme.scss"
    },
    {
      "hash": "sha256-TPy7vKZfWKMiM984ZORRBdBqFdJEjB+m6tP7SH2FT60=",
      "url": "assets/css/_typography.scss"
    },
    {
      "hash": "sha256-cHX9TWhaWpaxuRY2YbD61khegM2cvM3JUF9PtIGBJ5w=",
      "url": "assets/css/_utilities.scss"
    },
    {
      "hash": "sha256-mPBmaO3l7G9BEC5bY2DflMtZzPQztgNYSPhJ+0gWi5o=",
      "url": "assets/css/_variables.scss"
    },
    {
      "hash": "sha256-UzW3sqw/XiKkKqlfYHE4fnaYB5neuFlLqUWXn8cqCgs=",
      "url": "assets/css/app.css"
    },
    {
      "hash": "sha256-/fR6zQ0lQzd/HlMgNFTBI3610RXhKKt92KIkq8MhWhA=",
      "url": "assets/css/app.css.map"
    },
    {
      "hash": "sha256-5EgpnKJRj/HtSd9Gk/NTuS3Md0HUJ5La5sHBrSo1xg0=",
      "url": "assets/css/app.scss"
    },
    {
      "hash": "sha256-JqIbBjDS94muyBdXHLebgrRQVnc1iimYyRe3KCEx8bw=",
      "url": "assets/css/rules-list.md"
    },
    {
      "hash": "sha256-yTLS885RRZuKkO9IKK/FYAq1Ov+EprYb4Qb+fqKmKTY=",
      "url": "assets/data/blogs/Communication-Mastery-for-Digital-Business-Success.md"
    },
    {
      "hash": "sha256-r2yV9izLp6+BG09XEBroYRjCJ49OeqesOLkbv7GruRU=",
      "url": "assets/data/blogs/Digital-Assets-The-Real-Estate-of-the-Virtual-World.md"
    },
    {
      "hash": "sha256-JPIwbSJXAFfAkEIj8pVp+ff9rzCyM3QNYYsaT5G//g8=",
      "url": "assets/data/blogs/Don-t-Normalize-Common-Things-A-Philosophy-for-Business-Excellence.md"
    },
    {
      "hash": "sha256-/V0n785d5HpEeNneTkyqsm4tkiaPcV4R4OJjymdO3CU=",
      "url": "assets/data/blogs/GST-Rate-Deductions-for-E-commerce-A-Complete-Guide-by-VVG-ONLINE.md"
    },
    {
      "hash": "sha256-iWo/lMBl37fEf9fa75Csv3qilROirKtDx8E0tg3FWG8=",
      "url": "assets/data/blogs/Key-Performance-Indicators-KPIs.md"
    },
    {
      "hash": "sha256-BARKjofcaHCOQgDb+TG1dDHaUwfzQOCb2P98jg425ls=",
      "url": "assets/data/blogs/Operating-Model-Design.md"
    },
    {
      "hash": "sha256-g5bYTlmu/1JP2Zw/jkP0IcL8X5SEWrYb6tVMAsH2gSk=",
      "url": "assets/data/blogs/The-Digital-Marketing-Investment-Imperative.md"
    },
    {
      "hash": "sha256-ar/G5/Dixx1eK+IN5kEJtniyhik9jZ/2fnWEzC9Mtp4=",
      "url": "assets/data/blogs/capability-building.md"
    },
    {
      "hash": "sha256-atlk/wokwJJqH6UI32zYBuBqDLkJcX2JREmQ2nlJ/LI=",
      "url": "assets/data/blogs/design-thinking-workshops.md"
    },
    {
      "hash": "sha256-MnAwOCkST8Noi5GtLCCmKfjtB8XWLwRG9aNiCHaQ1AY=",
      "url": "assets/data/blogs/digital-transformation.md"
    },
    {
      "hash": "sha256-ZHjvV6pB1huos6HyVXAb5+IyjvFDDDrz+ZtvjqMYWHM=",
      "url": "assets/data/blogs/it-management-solutions.md"
    },
    {
      "hash": "sha256-pTyvcfdLo8wdJ8lULlLMaEf7dKj1n1E6+IFdLF5iqCQ=",
      "url": "assets/data/blogs/strategic-digital-marketing.md"
    },
    {
      "hash": "sha256-e5Ct99Lb7ewzhaXdOVhYNjtVAq81Js6AkRPNkhix73U=",
      "url": "assets/data/blogs/strategy-and-innovation.md"
    },
    {
      "hash": "sha256-0DZ4IBudU2cXmVj+I8xR5qSWR45noumeIn1pOX1k+08=",
      "url": "assets/data/dataset-manifest.json"
    },
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": "assets/data/dataset/docs/about.txt"
    },
    {
      "hash": "sha256-y6+oumIS+Ch6rk4QtOdMZgStBxF0V2Et6vmZ2aHNlyM=",
      "url": "assets/data/dataset/docs/contact-info.txt"
    },
    {
      "hash": "sha256-pr7qNbfGgbLRDjQH+YMTkIBDLG1ZdQCH9q33ERsnCkY=",
      "url": "assets/data/dataset/docs/digital-business-consulting-qna.txt"
    },
    {
      "hash": "sha256-r0F0RIu7KhzSmKanXRHz89R46LUl5XUjvzBTJ3n1S+M=",
      "url": "assets/data/dataset/knowledge/digital-business-consulting.csv"
    },
    {
      "hash": "sha256-DBFgmEUbPRiUkczYDUZRIcP1tukKw/6+uzW4rnTfE6c=",
      "url": "assets/data/dataset/knowledge/faq.csv"
    },
    {
      "hash": "sha256-1K7VVoIf/S4ii4qn615AF/wX1Sii+5UeqgiPfjGAO2U=",
      "url": "assets/data/dataset/prompts/Vikas-Model-Persona.md"
    },
    {
      "hash": "sha256-3SGhQCKexexvFuKijg8kxsAR+HimHDCrXaB/OMjFGC0=",
      "url": "assets/data/dataset/services/digital-business-consulting.json"
    },
    {
      "hash": "sha256-WpJUa0MlyrLsUIraf66TKuhMoUq8xnKx/Ct/V87EezQ=",
      "url": "assets/data/dataset/services/web-development.json"
    },
    {
      "hash": "sha256-2Wvou+lYygqNAzxreQrcAmsRh59RfD69Ugna3Hb53F8=",
      "url": "assets/data/facts-figures.json"
    },
    {
      "hash": "sha256-22CRubuz6nNG/mJh7xJ0H/d37aXf2BLx/Et3OmtRmDE=",
      "url": "assets/data/json/blog-index.json"
    },
    {
      "hash": "sha256-++mKJbMFq73earbY85dFdXxAVq2wHnwNOoDB7BF4Hrg=",
      "url": "assets/data/json/faq.json"
    },
    {
      "hash": "sha256-vjsakPS98ipv/nFXU4kcZmftildChINgrXaMWk+pJi0=",
      "url": "assets/data/json/json-ld.json"
    },
    {
      "hash": "sha256-6Oc8VL4xhWa3xDdQA8fEaXxl7FSex+JoGnIZR+nJ/po=",
      "url": "assets/data/json/metadata.json"
    },
    {
      "hash": "sha256-mhYTBskjh4MAk0PpmMxJctAYSXty2hvN1GRltblDOks=",
      "url": "assets/data/json/open-graph.json"
    },
    {
      "hash": "sha256-WBm3G+JGZV4eGirLz6KOGhxuE129Hd6SIYQmQne2boU=",
      "url": "assets/data/json/twitter-card.json"
    },
    {
      "hash": "sha256-aTKj0tJI12sYs/+V0dqKLejTS90eZcREcPwWcd2Cc1k=",
      "url": "assets/data/services.json"
    },
    {
      "hash": "sha256-GmLdKrprt/cHQ0KYyn8NG7UhY/cDJQb0T04coaQSQXg=",
      "url": "assets/data/vikas-dataset-augmented-v1-backup.jsonl"
    },
    {
      "hash": "sha256-/LMdRce08Br6ATNTmYss9NIAkhx1WODAQVWUggbvUmY=",
      "url": "assets/data/vikas-dataset-augmented.jsonl"
    },
    {
      "hash": "sha256-5EorvTKPBz0VBaxS26oe5DzOC569GDpfELRcVD1Q5iI=",
      "url": "assets/images/profiles/logo-2025.svg"
    },
    {
      "hash": "sha256-0Nr7sFaR6NB1lNbTeyazRPiUg2aAuFXYWYth/j5kOrg=",
      "url": "assets/images/profiles/logo-edge-2025-240x240.svg"
    },
    {
      "hash": "sha256-EnZhgRtOpfKj6Vdph58+WxTzNzBLnMpKurfEHHj5XSs=",
      "url": "assets/images/twitter-cards/about-twitter-card.png"
    },
    {
      "hash": "sha256-A40CbrPKhC7FHZlsdjkTsEUQHtP7D2GTEm1q3E4Lbxs=",
      "url": "assets/images/twitter-cards/blog-archives-twitter-card.png"
    },
    {
      "hash": "sha256-CQhDuHapm5BhSQxoCh8/y46BCYFteZhr8R0RScHEvDk=",
      "url": "assets/images/twitter-cards/blog-twitter-card.png"
    },
    {
      "hash": "sha256-Ylju5CdOPcWSReRp3CGXA4BLC/+RI9SWd/Zy26zz6EY=",
      "url": "assets/images/twitter-cards/card-mapping.json"
    },
    {
      "hash": "sha256-3GOmSw18POUxJCQ3l65ffpAyvo3SxKQ8qsWkUPdotiQ=",
      "url": "assets/images/twitter-cards/communication-mastery-for-digital-business-success-twitter-card.png"
    },
    {
      "hash": "sha256-8GNeJIgQUSZhYXybVodT/N4s23hFDlVKyrukPmyw6Rg=",
      "url": "assets/images/twitter-cards/contact-twitter-card.png"
    },
    {
      "hash": "sha256-C7keuomZpCHi+yNcc/FEl+8bX91hMirShxCSj1qfSRc=",
      "url": "assets/images/twitter-cards/digital-assets-the-real-estate-of-the-virtual-world-twitter-card.png"
    },
    {
      "hash": "sha256-k8fPr0xxaYAOqr7ssK7f7HI4OalC/QlnSDDPEHd1zH8=",
      "url": "assets/images/twitter-cards/dont-normalize-common-things-a-philosophy-for-business-excellence-twitter-card.png"
    },
    {
      "hash": "sha256-M1w4EPjhfeEzXXDWNIIVP9u40pmn09UBZwt8PQq8vwY=",
      "url": "assets/images/twitter-cards/gst-rate-deductions-for-e-commerce-a-complete-guide-by-vvg-online-twitter-card.png"
    },
    {
      "hash": "sha256-fY5ACu5yV10y/BcGgwB+OGrrNJl5YQibVjJue1UkhCE=",
      "url": "assets/images/twitter-cards/home-twitter-card.png"
    },
    {
      "hash": "sha256-K+e1BlUrbupvAs6vTvUsvNgkSJ0XIf3anH5H7Z4Zp50=",
      "url": "assets/images/twitter-cards/key-performance-indicators-kpis-twitter-card.png"
    },
    {
      "hash": "sha256-3w/J38rVbodZTljvrBu+E7YR8p7yUvLcS/GomvFafTw=",
      "url": "assets/images/twitter-cards/operating-model-design-twitter-card.png"
    },
    {
      "hash": "sha256-ubp22MDXqW+uyhCjnwre4MLV3KxCn/E9wXa1ZuunVSk=",
      "url": "assets/images/twitter-cards/services-twitter-card.png"
    },
    {
      "hash": "sha256-oDMOvD6SequBlqoE1bm33rNB7ZBN49YmztmBfLUWl3E=",
      "url": "assets/images/twitter-cards/the-digital-marketing-investment-imperative-twitter-card.png"
    },
    {
      "hash": "sha256-tB8u9ObDOyptJsUGI1vD6QnINAuLD3mSdIMPkywh7ug=",
      "url": "assets/images/twitter-cards/vvg-online-home-twitter-card.png"
    },
    {
      "hash": "sha256-ygBMATi7Jbj0glJA+A4QzZGf2GnXomvD8BBvayTJlnI=",
      "url": "assets/images/twitter-cards/vvg-online-home-twitter-card.svg"
    },
    {
      "hash": "sha256-MYxqUKYNOwwveEwm9Le7Zm6Gkf6OE49gqvFiWQi0HtM=",
      "url": "assets/js/boot-sequence.js"
    },
    {
      "hash": "sha256-UgQ3/Svn+a8VSXM0OX7Qj4Z9Se7eonDblfJuQegq8q0=",
      "url": "assets/js/chat-worker.js"
    },
    {
      "hash": "sha256-qG4Th75axq07xY57mwLKCw2Tnn6jZRsleJHHLb7Y68k=",
      "url": "assets/js/chat.js"
    },
    {
      "hash": "sha256-NFJWB5h1vMZ+UJj4ODHqSs/QQN7iZYETPZ3GjEJqY2w=",
      "url": "assets/js/meta.js"
    },
    {
      "hash": "sha256-Ufg2vQry2tyfkK1iA96/BBTViZVM8x7X4Y2YrpsYJ8Q=",
      "url": "assets/js/modelCache.js"
    },
    {
      "hash": "sha256-cdqdXYxOKFSZ3j6xHn2U14XnPeZk8aWK3Ni0KngpisY=",
      "url": "assets/js/redesign.js"
    },
    {
      "hash": "sha256-7gQA04mcmQ1cE7Sz+GfmDI/ICuryD8+MqZFvtTcf7IU=",
      "url": "assets/js/theme.js"
    },
    {
      "hash": "sha256-V8QA46rRrEQ7nMrJNVdHDTujpSGl5CTdEHyklV1Ac5E=",
      "url": "assets/js/wordpiece-tokenizer.js"
    },
    {
      "hash": "sha256-t9m+spSadqxLjNdGtfQTta4UzgGBxLV8V+91mL1ZaNA=",
      "url": "assets/models/intent-classifier.onnx"
    },
    {
      "hash": "sha256-BsJRVZ2YQem/z4Q/WAaGWuZxjR4TXngbrnNnvb7s53U=",
      "url": "assets/models/intent-classifier.onnx.bak"
    },
    {
      "hash": "sha256-C6Bt6q2cMCFtbnE6ct6tnMbGCLEM/IOh9cGJ+5D4eMA=",
      "url": "assets/models/intent-labels.json"
    },
    {
      "hash": "sha256-WNIu78HhSpXL7Y9Ju04Nqci5+4LTGv1ibwTrZ4TMnQg=",
      "url": "assets/models/tokenizer-vocab.json"
    },
    {
      "hash": "sha256-mE9ZtmWjspoEeq95nB8hind8EmhGMa2BUYFlJf0N3Pw=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-WKPPx24VUnPQx0TNcu+N7vLFnMbAcF4nVfGh/n4/8/Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-1YkLW3nSdXu3A973fJRYjm0p0kajoRH74m3x8LZMStI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-5IS5Pbs9TWHgfXH8b+vKA4/xqeTDZFjsFRxfXFktKHs=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-Xnb3e9NBaUWOeig64Ha0o7T3cRfNjDIB6qAA4gLc060=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-cCJeSsKR93v5JD1jXGfoXKRQ8X9XGJg2uVb7vxz9GYo=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-sPyuX8l3p4mGNEHxfH0gV0CR5BTrHZZrKo30LD+xwEY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-PWvQiftGYKIGScnEXjXVIXuVlWtK5/W9Oc7+QcrbAWo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-ZhbMmJdZgkZzAkF1AwTUeT6zV1t7J5gvYlFtotm/THo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-WGrjSmiagKCCjp490wunyOh0DlHHUo2+/PK/hrV1Sfc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-86z4rrZg65paw3GVPMvc7ml5MFTPur0obtHYWo4Xo7c=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-yyKX7OANyk57JkCeetq2x22fF9LWKayXQIv5p5mKRVk=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-V1pQsFprZ70IfTjqsVqgE5ERZw2pPY4FYvrhk6uztuw=",
      "url": "llms.txt"
    },
    {
      "hash": "sha256-D3hkqoz5MEmVRgMphIGTuaiCEfgqlLIY66hoPYfvSzk=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-7Zefngs3mxqaBtsXpTJLdTw/RP7TiDlRfE3mnX1sMfA=",
      "url": "robots.txt"
    },
    {
      "hash": "sha256-s0anlv6DfSAMxV/3haGB6vrHQktFiNtqZxfd3dSaMTA=",
      "url": "scripts/intent-labels.json"
    },
    {
      "hash": "sha256-GmLdKrprt/cHQ0KYyn8NG7UhY/cDJQb0T04coaQSQXg=",
      "url": "scripts/vikas-dataset-augmented.jsonl"
    },
    {
      "hash": "sha256-Ytt6X82mMknnBs5cwyzFJKDiC5RR0OZQT7L9BW3j/a8=",
      "url": "sitemap.xml"
    },
    {
      "hash": "sha256-/vTwhZ8FHgUB76wrd2jlpJfn8NVUCc2MtE2vEEDlz3I=",
      "url": "test-chat.html"
    }
  ]
};
